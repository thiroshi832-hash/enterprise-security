Enterprise Security Management System (ESMS)
Curated Open-Access Reference Package

This package contains high-quality free/open-access resources,
whitepapers, frameworks, and official documentation useful for:
- Enterprise Security Management System reports
- ISO 27001 / NIST research
- Cybersecurity governance
- SOC and incident response
- Zero Trust architecture
- Cloud security and compliance

1. NIST Cybersecurity Framework 2.0
   URL: https://nvlpubs.nist.gov/nistpubs/CSWP/NIST.CSWP.29.pdf
   Description: Official NIST cybersecurity framework PDF

2. NIST SP 800-53
   URL: https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final
   Description: Security and privacy controls for systems and organizations

3. NIST SP 800-61 Incident Response Guide
   URL: https://csrc.nist.gov/pubs/sp/800/61/r2/final
   Description: Computer security incident handling guide

4. NIST SP 800-37 RMF
   URL: https://csrc.nist.gov/pubs/sp/800/37/r2/final
   Description: Risk Management Framework guide

5. CIS Controls v8
   URL: https://www.cisecurity.org/controls/v8
   Description: Critical security controls

6. OWASP Top 10
   URL: https://owasp.org/www-project-top-ten/
   Description: Web application security risks

7. OWASP ASVS
   URL: https://owasp.org/www-project-application-security-verification-standard/
   Description: Application security verification standard

8. Microsoft Zero Trust Guidance
   URL: https://learn.microsoft.com/en-us/security/zero-trust/
   Description: Enterprise Zero Trust architecture guidance

9. AWS Security Best Practices
   URL: https://aws.amazon.com/architecture/security-identity-compliance/
   Description: Cloud security architecture guidance

10. Google Cloud Security Foundations
   URL: https://cloud.google.com/architecture/security-foundations
   Description: Google Cloud enterprise security guidance

11. CISA Cybersecurity Resources
   URL: https://www.cisa.gov/cybersecurity
   Description: US cybersecurity agency resources

12. MITRE ATT&CK
   URL: https://attack.mitre.org/
   Description: Adversary tactics and techniques knowledge base

13. The CISO's Guide to Cybersecurity Frameworks
   URL: https://www.attackiq.com/wp-content/uploads/2021/02/cisos-guide-to-the-top-cybersecurity-frameworks.pdf
   Description: Framework comparison whitepaper

14. HITRUST CSF Comparison Whitepaper
   URL: https://hitrustalliance.net/hubfs/CSFComparisonWhitpaper-1.pdf
   Description: Comparison of major security frameworks

